## Required libraries should be placed here before building wheel package.  

  - k4a
  - DepthEngine

The actual names may differ depending on version and platform.  

> On Windows, the libraries should be named k4a.dll and depthengine*.dll.  

> On Linux, the libraries should be named libk4a.so and libdepthengine.*  
